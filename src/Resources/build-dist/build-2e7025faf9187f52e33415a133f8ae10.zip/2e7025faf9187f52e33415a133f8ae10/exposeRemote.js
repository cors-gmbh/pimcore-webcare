
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.corswebcare = "/bundles/corswebcare/studio/2e7025faf9187f52e33415a133f8ae10/static/js/remoteEntry.js"

      
    