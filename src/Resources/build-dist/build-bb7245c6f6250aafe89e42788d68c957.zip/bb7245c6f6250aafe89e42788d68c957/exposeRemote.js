
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.corswebcare = "/bundles/corswebcare/studio/bb7245c6f6250aafe89e42788d68c957/static/js/remoteEntry.js"

      
    