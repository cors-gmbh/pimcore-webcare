
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.corswebcare = "/bundles/corswebcare/studio/d9c8631ff3b40e6a94598106206a9da0/static/js/remoteEntry.js"

      
    